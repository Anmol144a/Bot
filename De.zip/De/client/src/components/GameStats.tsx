import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Gamepad2, Trophy } from "lucide-react";

interface GameStatsProps {
  totalGames: number;
  winRate: number;
  totalWagered: number;
  totalWon: number;
  activeGames: number;
  avgGameDuration: string;
}

export default function GameStats({ totalGames, winRate, totalWagered, totalWon, activeGames, avgGameDuration }: GameStatsProps) {
  const profitLoss = totalWon - totalWagered;
  const isProfitable = profitLoss > 0;
  
  return (
    <Card data-testid="card-game-stats">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gamepad2 className="h-5 w-5" />
          Game Statistics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Games</span>
              <span className="font-medium" data-testid="text-total-games">{totalGames.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Active Games</span>
              <span className="font-medium" data-testid="text-active-games">{activeGames}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Avg Duration</span>
              <span className="font-medium" data-testid="text-avg-duration">{avgGameDuration}</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Wagered</span>
              <span className="font-medium" data-testid="text-total-wagered">{totalWagered.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Won</span>
              <span className="font-medium" data-testid="text-total-won">{totalWon.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">P&L</span>
              <span className={`font-medium flex items-center gap-1 ${
                isProfitable ? 'text-gaming-success' : 'text-gaming-danger'
              }`} data-testid="text-profit-loss">
                {isProfitable ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {isProfitable ? '+' : ''}{profitLoss.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-gaming-gold" />
              <span className="text-sm font-medium">Win Rate</span>
            </div>
            <span className="text-sm font-medium" data-testid="text-win-rate">{winRate.toFixed(1)}%</span>
          </div>
          <Progress value={winRate} className="h-2" data-testid="progress-win-rate" />
        </div>
      </CardContent>
    </Card>
  );
}