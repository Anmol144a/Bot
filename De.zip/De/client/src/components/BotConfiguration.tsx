import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Settings, Save, Eye, EyeOff } from "lucide-react";
import { useState } from "react";

interface BotConfigurationProps {
  botToken: string;
  apiWalletId: string;
  apiTransferKey: string;
  scanInterval: number;
  logsChannelId: string;
  withdrawalChannelId: string;
  fairPlayChannelId: string;
  isTokenVisible: boolean;
}

export default function BotConfiguration({
  botToken,
  apiWalletId,
  apiTransferKey,
  scanInterval,
  logsChannelId,
  withdrawalChannelId,
  fairPlayChannelId,
  isTokenVisible: initialTokenVisible
}: BotConfigurationProps) {
  const [isTokenVisible, setIsTokenVisible] = useState(initialTokenVisible);
  const [isDirty, setIsDirty] = useState(false);
  const [isAdvancedVisible, setIsAdvancedVisible] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    console.log('Saving bot configuration...');
    // TODO: Implement actual save functionality
    setTimeout(() => {
      setIsSaving(false);
      setIsDirty(false);
    }, 1500);
  };

  const handleInputChange = () => {
    setIsDirty(true);
  };

  const maskToken = (token: string) => {
    if (!token || token.length < 8) return token;
    return token.slice(0, 4) + '•'.repeat(token.length - 8) + token.slice(-4);
  };

  return (
    <Card data-testid="card-bot-configuration">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Bot Configuration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Discord Token */}
        <div className="space-y-2">
          <Label htmlFor="bot-token">Discord Bot Token</Label>
          <div className="flex gap-2">
            <Input
              id="bot-token"
              type="text"
              value={isTokenVisible ? botToken : maskToken(botToken)}
              onChange={handleInputChange}
              placeholder="Enter Discord bot token"
              className="flex-1"
              data-testid="input-bot-token"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsTokenVisible(!isTokenVisible)}
              data-testid="button-toggle-token-visibility"
            >
              {isTokenVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          </div>
          {!botToken && (
            <p className="text-sm text-muted-foreground">
              Required for bot to connect to Discord
            </p>
          )}
        </div>

        {/* Channel Configuration */}
        <div className="space-y-4">
          <h4 className="font-medium flex items-center gap-2">
            Discord Channels
            <Badge variant="outline" className="text-xs">IDs</Badge>
          </h4>
          
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label htmlFor="logs-channel">Logs Channel ID</Label>
              <Input
                id="logs-channel"
                type="text"
                defaultValue={logsChannelId}
                onChange={handleInputChange}
                placeholder="Channel ID for game logs"
                data-testid="input-logs-channel"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="withdrawal-channel">Withdrawal Channel ID</Label>
              <Input
                id="withdrawal-channel"
                type="text"
                defaultValue={withdrawalChannelId}
                onChange={handleInputChange}
                placeholder="Channel ID for withdrawal notifications"
                data-testid="input-withdrawal-channel"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="fairplay-channel">Fair Play Channel ID</Label>
              <Input
                id="fairplay-channel"
                type="text"
                defaultValue={fairPlayChannelId}
                onChange={handleInputChange}
                placeholder="Channel ID for fair play announcements"
                data-testid="input-fairplay-channel"
              />
            </div>
          </div>
        </div>

        {/* Advanced Settings Toggle */}
        <div className="flex items-center justify-between">
          <Label htmlFor="advanced-settings" className="font-medium">
            Advanced Settings
          </Label>
          <Switch
            id="advanced-settings"
            checked={isAdvancedVisible}
            onCheckedChange={setIsAdvancedVisible}
            data-testid="switch-advanced-settings"
          />
        </div>

        {/* Advanced Settings */}
        {isAdvancedVisible && (
          <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
            <div className="space-y-2">
              <Label htmlFor="api-wallet">Apirone Wallet ID</Label>
              <Input
                id="api-wallet"
                type="text"
                defaultValue={apiWalletId}
                onChange={handleInputChange}
                placeholder="Wallet ID for cryptocurrency payments"
                data-testid="input-api-wallet"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="api-transfer">Apirone Transfer Key</Label>
              <Input
                id="api-transfer"
                type="password"
                defaultValue={apiTransferKey}
                onChange={handleInputChange}
                placeholder="Transfer key for cryptocurrency operations"
                data-testid="input-api-transfer"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="scan-interval">Scan Interval (ms)</Label>
              <Input
                id="scan-interval"
                type="number"
                defaultValue={scanInterval}
                onChange={handleInputChange}
                placeholder="60000"
                data-testid="input-scan-interval"
              />
              <p className="text-xs text-muted-foreground">
                How often to check for payment confirmations
              </p>
            </div>
          </div>
        )}

        {/* Save Button */}
        <div className="flex justify-end">
          <Button
            onClick={handleSave}
            disabled={!isDirty || isSaving}
            className="flex items-center gap-2"
            data-testid="button-save-config"
          >
            <Save className="h-4 w-4" />
            {isSaving ? 'Saving...' : 'Save Configuration'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}