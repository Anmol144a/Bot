import BotConfiguration from '../BotConfiguration'

export default function BotConfigurationExample() {
  return (
    <BotConfiguration
      botToken="MTQxOTI2MTQ0Nzg3NTMzMDEwOA.GxY2Kw.example_token_here_1234567890"
      apiWalletId="btc-wallet-abc123"
      apiTransferKey="transfer-key-xyz789"
      scanInterval={60000}
      logsChannelId="1419261447875330108"
      withdrawalChannelId="1419261447875330108"
      fairPlayChannelId="1419261447875330108"
      isTokenVisible={false}
    />
  )
}