import GameActivity from '../GameActivity'

export default function GameActivityExample() {
  // TODO: remove mock functionality
  const mockActivities = [
    {
      id: '1',
      userId: 'user1',
      username: 'GamingKing97',
      game: 'Tower',
      action: 'cashout' as const,
      amount: 2340,
      multiplier: 3.4,
      timestamp: new Date(Date.now() - 30000)
    },
    {
      id: '2',
      userId: 'user2',
      username: 'BetMaster',
      game: 'Tower',
      action: 'win' as const,
      amount: 1250,
      timestamp: new Date(Date.now() - 120000)
    },
    {
      id: '3',
      userId: 'user3',
      username: 'LuckyPlayer',
      game: 'Tower',
      action: 'loss' as const,
      amount: 500,
      timestamp: new Date(Date.now() - 300000)
    },
    {
      id: '4',
      userId: 'user4',
      username: 'HighRoller',
      game: 'Tower',
      action: 'cashout' as const,
      amount: 5670,
      multiplier: 7.8,
      timestamp: new Date(Date.now() - 450000)
    },
    {
      id: '5',
      userId: 'user5',
      username: 'CryptoWinner',
      game: 'Tower',
      action: 'started' as const,
      amount: 200,
      timestamp: new Date(Date.now() - 600000)
    },
    {
      id: '6',
      userId: 'user6',
      username: 'DiamondHunter',
      game: 'Tower',
      action: 'loss' as const,
      amount: 1000,
      timestamp: new Date(Date.now() - 780000)
    }
  ];

  return (
    <GameActivity activities={mockActivities} />
  )
}