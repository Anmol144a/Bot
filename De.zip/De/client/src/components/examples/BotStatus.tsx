import BotStatus from '../BotStatus'

export default function BotStatusExample() {
  return (
    <BotStatus
      isOnline={true}
      guilds={12}
      users={4567}
      gamesActive={23}
      uptime="2d 14h 32m"
    />
  )
}