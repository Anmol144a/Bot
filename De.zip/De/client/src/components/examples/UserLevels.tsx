import UserLevels from '../UserLevels'

export default function UserLevelsExample() {
  // TODO: remove mock functionality
  const mockLevels = [
    { name: 'Emberling', threshold: 200, reward: 2, emoji: '🔥', description: 'Beginner spark.', color: '#ff6f3c' },
    { name: 'Ironclad', threshold: 1000, reward: 5, emoji: '🛡️', description: 'Strong starter.', color: '#5c5c5c' },
    { name: 'Steelbound', threshold: 2000, reward: 10, emoji: '⚔️', description: 'Durable grinder.', color: '#8a8f9e' },
    { name: 'Frostborne', threshold: 5000, reward: 20, emoji: '❄️', description: 'Cool, sharp player.', color: '#00cfff' },
    { name: 'Solarflare', threshold: 12500, reward: 40, emoji: '☀️', description: 'Shining with energy.', color: '#ffd700' },
    { name: 'Bloodfang', threshold: 25000, reward: 80, emoji: '🩸', description: 'Fierce challenger.', color: '#b3001b' }
  ];

  const mockTopUsers = [
    { 
      userId: '1', 
      username: 'GamingKing97', 
      totalWagered: 45230, 
      currentLevel: mockLevels[4], 
      nextLevel: mockLevels[5], 
      progress: 75 
    },
    { 
      userId: '2', 
      username: 'CryptoWinner', 
      totalWagered: 23450, 
      currentLevel: mockLevels[4], 
      nextLevel: mockLevels[5], 
      progress: 45 
    },
    { 
      userId: '3', 
      username: 'BetMaster', 
      totalWagered: 18900, 
      currentLevel: mockLevels[3], 
      nextLevel: mockLevels[4], 
      progress: 89 
    },
    { 
      userId: '4', 
      username: 'LuckyPlayer', 
      totalWagered: 12600, 
      currentLevel: mockLevels[3], 
      nextLevel: mockLevels[4], 
      progress: 34 
    },
    { 
      userId: '5', 
      username: 'HighRoller', 
      totalWagered: 8950, 
      currentLevel: mockLevels[2], 
      nextLevel: mockLevels[3], 
      progress: 67 
    }
  ];

  return (
    <UserLevels
      topUsers={mockTopUsers}
      levels={mockLevels}
    />
  )
}