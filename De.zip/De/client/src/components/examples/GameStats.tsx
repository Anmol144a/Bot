import GameStats from '../GameStats'

export default function GameStatsExample() {
  return (
    <GameStats
      totalGames={15847}
      winRate={42.3}
      totalWagered={892650}
      totalWon={934280}
      activeGames={23}
      avgGameDuration="4m 32s"
    />
  )
}