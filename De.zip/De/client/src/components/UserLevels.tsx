import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Crown, Star, Award } from "lucide-react";

interface Level {
  name: string;
  threshold: number;
  reward: number;
  emoji: string;
  description: string;
  color: string;
}

interface UserLevel {
  userId: string;
  username: string;
  avatar?: string;
  totalWagered: number;
  currentLevel: Level | null;
  nextLevel: Level | null;
  progress: number;
}

interface UserLevelsProps {
  topUsers: UserLevel[];
  levels: Level[];
}

export default function UserLevels({ topUsers, levels }: UserLevelsProps) {
  return (
    <Card data-testid="card-user-levels">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-gaming-gold" />
          Level System
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Level Tiers Overview */}
          <div className="mb-6">
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <Star className="h-4 w-4" />
              Available Levels
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {levels.slice(0, 6).map((level, index) => (
                <div key={index} className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                  <span className="text-sm">{level.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium truncate">{level.name}</p>
                    <p className="text-xs text-muted-foreground">{level.threshold.toLocaleString()} wagered</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    +{level.reward}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          {/* Top Players */}
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <Award className="h-4 w-4" />
              Top Players
            </h4>
            <div className="space-y-3">
              {topUsers.map((user, index) => (
                <div key={user.userId} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center ${
                      index === 0 ? 'bg-gaming-gold text-black' :
                      index === 1 ? 'bg-gray-400 text-black' :
                      index === 2 ? 'bg-amber-600 text-white' :
                      'bg-muted text-foreground'
                    }`}>
                      {index + 1}
                    </span>
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm truncate" data-testid={`text-username-${index}`}>
                        {user.username}
                      </span>
                      {user.currentLevel && (
                        <Badge variant="outline" className="text-xs">
                          {user.currentLevel.emoji} {user.currentLevel.name}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium" data-testid={`text-wagered-${index}`}>
                          {user.totalWagered.toLocaleString()}
                        </span>
                      </div>
                      {user.nextLevel && (
                        <Progress 
                          value={user.progress} 
                          className="h-1" 
                          data-testid={`progress-level-${index}`}
                        />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}