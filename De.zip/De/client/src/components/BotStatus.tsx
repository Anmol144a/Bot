import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Activity, Users, Gamepad2, TrendingUp } from "lucide-react";

interface BotStatusProps {
  isOnline: boolean;
  guilds: number;
  users: number;
  gamesActive: number;
  uptime: string;
}

export default function BotStatus({ isOnline, guilds, users, gamesActive, uptime }: BotStatusProps) {
  const [isStarting, setIsStarting] = useState(false);

  const handleToggleBot = () => {
    setIsStarting(true);
    console.log(isOnline ? 'Stopping bot...' : 'Starting bot...');
    // TODO: Implement actual bot start/stop functionality
    setTimeout(() => setIsStarting(false), 2000);
  };

  return (
    <Card data-testid="card-bot-status">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Bot Status
        </CardTitle>
        <Badge 
          variant={isOnline ? "default" : "destructive"}
          className={`flex items-center gap-1 ${isOnline ? 'bg-discord-green' : 'bg-discord-red'}`}
          data-testid={`status-bot-${isOnline ? 'online' : 'offline'}`}
        >
          <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-white' : 'bg-white'}`} />
          {isOnline ? 'Online' : 'Offline'}
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium" data-testid="text-guilds">{guilds}</p>
              <p className="text-xs text-muted-foreground">Guilds</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium" data-testid="text-users">{users.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total Users</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Gamepad2 className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium" data-testid="text-games-active">{gamesActive}</p>
              <p className="text-xs text-muted-foreground">Active Games</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium" data-testid="text-uptime">{uptime}</p>
              <p className="text-xs text-muted-foreground">Uptime</p>
            </div>
          </div>
        </div>
        <Button 
          onClick={handleToggleBot}
          disabled={isStarting}
          variant={isOnline ? "destructive" : "default"}
          className="w-full"
          data-testid={`button-${isOnline ? 'stop' : 'start'}-bot`}
        >
          {isStarting ? 'Processing...' : (isOnline ? 'Stop Bot' : 'Start Bot')}
        </Button>
      </CardContent>
    </Card>
  );
}