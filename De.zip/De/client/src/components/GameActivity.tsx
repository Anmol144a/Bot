import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TrendingUp, TrendingDown, Clock, Trophy } from "lucide-react";

interface GameActivityItem {
  id: string;
  userId: string;
  username: string;
  avatar?: string;
  game: string;
  action: 'win' | 'loss' | 'cashout' | 'started';
  amount: number;
  multiplier?: number;
  timestamp: Date;
}

interface GameActivityProps {
  activities: GameActivityItem[];
}

export default function GameActivity({ activities }: GameActivityProps) {
  const getActionIcon = (action: string) => {
    switch (action) {
      case 'win':
        return <Trophy className="h-3 w-3 text-gaming-success" />;
      case 'cashout':
        return <TrendingUp className="h-3 w-3 text-gaming-gold" />;
      case 'loss':
        return <TrendingDown className="h-3 w-3 text-gaming-danger" />;
      default:
        return <Clock className="h-3 w-3 text-muted-foreground" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'win':
        return 'bg-gaming-success';
      case 'cashout':
        return 'bg-gaming-gold';
      case 'loss':
        return 'bg-gaming-danger';
      default:
        return 'bg-muted';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  return (
    <Card data-testid="card-game-activity">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 hover-elevate">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={activity.avatar} />
                  <AvatarFallback>{activity.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-sm truncate" data-testid={`text-username-${activity.id}`}>
                      {activity.username}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {activity.game}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {getActionIcon(activity.action)}
                    <span className="capitalize">{activity.action}</span>
                    {activity.multiplier && activity.action === 'cashout' && (
                      <span className="text-gaming-gold font-medium">
                        {activity.multiplier}x
                      </span>
                    )}
                    <span className="ml-auto" data-testid={`text-time-${activity.id}`}>
                      {formatTime(activity.timestamp)}
                    </span>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`text-sm font-medium flex items-center gap-1 ${
                    activity.action === 'win' || activity.action === 'cashout' 
                      ? 'text-gaming-success' 
                      : activity.action === 'loss' 
                      ? 'text-gaming-danger' 
                      : 'text-foreground'
                  }`} data-testid={`text-amount-${activity.id}`}>
                    {activity.action === 'win' || activity.action === 'cashout' ? '+' : 
                     activity.action === 'loss' ? '-' : ''}
                    {activity.amount.toLocaleString()}
                  </div>
                  <div className={`w-2 h-2 rounded-full ${getActionColor(activity.action)}`} />
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}