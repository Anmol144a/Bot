import BotStatus from "@/components/BotStatus";
import GameStats from "@/components/GameStats";
import UserLevels from "@/components/UserLevels";
import GameActivity from "@/components/GameActivity";
import BotConfiguration from "@/components/BotConfiguration";

export default function Dashboard() {
  // TODO: remove mock functionality - replace with real data from backend
  const mockBotStatus = {
    isOnline: true,
    guilds: 12,
    users: 4567,
    gamesActive: 23,
    uptime: "2d 14h 32m"
  };

  const mockGameStats = {
    totalGames: 15847,
    winRate: 42.3,
    totalWagered: 892650,
    totalWon: 934280,
    activeGames: 23,
    avgGameDuration: "4m 32s"
  };

  const mockLevels = [
    { name: 'Emberling', threshold: 200, reward: 2, emoji: '🔥', description: 'Beginner spark.', color: '#ff6f3c' },
    { name: 'Ironclad', threshold: 1000, reward: 5, emoji: '🛡️', description: 'Strong starter.', color: '#5c5c5c' },
    { name: 'Steelbound', threshold: 2000, reward: 10, emoji: '⚔️', description: 'Durable grinder.', color: '#8a8f9e' },
    { name: 'Frostborne', threshold: 5000, reward: 20, emoji: '❄️', description: 'Cool, sharp player.', color: '#00cfff' },
    { name: 'Solarflare', threshold: 12500, reward: 40, emoji: '☀️', description: 'Shining with energy.', color: '#ffd700' },
    { name: 'Bloodfang', threshold: 25000, reward: 80, emoji: '🩸', description: 'Fierce challenger.', color: '#b3001b' }
  ];

  const mockTopUsers = [
    { 
      userId: '1', 
      username: 'GamingKing97', 
      totalWagered: 45230, 
      currentLevel: mockLevels[4], 
      nextLevel: mockLevels[5], 
      progress: 75 
    },
    { 
      userId: '2', 
      username: 'CryptoWinner', 
      totalWagered: 23450, 
      currentLevel: mockLevels[4], 
      nextLevel: mockLevels[5], 
      progress: 45 
    },
    { 
      userId: '3', 
      username: 'BetMaster', 
      totalWagered: 18900, 
      currentLevel: mockLevels[3], 
      nextLevel: mockLevels[4], 
      progress: 89 
    }
  ];

  const mockActivities = [
    {
      id: '1',
      userId: 'user1',
      username: 'GamingKing97',
      game: 'Tower',
      action: 'cashout' as const,
      amount: 2340,
      multiplier: 3.4,
      timestamp: new Date(Date.now() - 30000)
    },
    {
      id: '2',
      userId: 'user2',
      username: 'BetMaster',
      game: 'Tower',
      action: 'win' as const,
      amount: 1250,
      timestamp: new Date(Date.now() - 120000)
    },
    {
      id: '3',
      userId: 'user3',
      username: 'LuckyPlayer',
      game: 'Tower',
      action: 'loss' as const,
      amount: 500,
      timestamp: new Date(Date.now() - 300000)
    }
  ];

  const mockBotConfig = {
    botToken: "MTQxOTI2MTQ0Nzg3NTMzMDEwOA.GxY2Kw.example_token_here_1234567890",
    apiWalletId: "btc-wallet-abc123",
    apiTransferKey: "transfer-key-xyz789",
    scanInterval: 60000,
    logsChannelId: "1419261447875330108",
    withdrawalChannelId: "1419261447875330108",
    fairPlayChannelId: "1419261447875330108",
    isTokenVisible: false
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-border pb-6">
        <h1 className="text-3xl font-bold" data-testid="heading-dashboard">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Monitor and manage your Discord gambling bot in real-time
        </p>
      </div>

      {/* Top Row - Bot Status and Game Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <BotStatus {...mockBotStatus} />
        <GameStats {...mockGameStats} />
      </div>

      {/* Middle Row - User Levels and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <UserLevels topUsers={mockTopUsers} levels={mockLevels} />
        <GameActivity activities={mockActivities} />
      </div>

      {/* Bottom Row - Configuration */}
      <div className="grid grid-cols-1 gap-6">
        <BotConfiguration {...mockBotConfig} />
      </div>
    </div>
  );
}