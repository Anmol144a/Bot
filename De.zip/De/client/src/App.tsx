import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import Dashboard from "@/pages/Dashboard";
import NotFound from "@/pages/not-found";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      {/* Add more routes as needed */}
      {/* <Route path="/analytics" component={Analytics} /> */}
      {/* <Route path="/users" component={Users} /> */}
      {/* <Route path="/games" component={Games} /> */}
      {/* <Route path="/security" component={Security} /> */}
      {/* <Route path="/settings" component={Settings} /> */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isDarkMode, setIsDarkMode] = useState(true);

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={style as React.CSSProperties}>
          <div className="flex h-screen w-full">
            <AppSidebar />
            <div className="flex flex-col flex-1">
              <header className="flex items-center justify-between p-4 border-b border-border bg-background">
                <div className="flex items-center gap-4">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-discord-blurple rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-sm">RZ</span>
                    </div>
                    <div>
                      <h2 className="font-semibold text-lg">RawbetZ Bot Manager</h2>
                      <p className="text-xs text-muted-foreground">Professional Discord Bot Control Panel</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-gaming-success rounded-full animate-pulse" data-testid="status-indicator"></div>
                  <span className="text-sm text-muted-foreground">System Online</span>
                </div>
              </header>
              <main className="flex-1 overflow-auto p-6 bg-background">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
